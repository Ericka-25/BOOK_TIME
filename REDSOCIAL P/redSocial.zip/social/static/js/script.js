// app/static/js/scripts.js
document.addEventListener('DOMContentLoaded', function () {
    console.log('JavaScript cargado y funcionando.');
});
